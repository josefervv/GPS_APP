package com.example.udp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationRequest;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    public EditText ip1, ip2;
    TextView tv_lat, tv_lon, tv_altitude, tv_accuracy, tv_speed;
    public String portudp="50000", porttcp="51000";
    public Button send;
    public DatagramSocket dsock;
    public Socket sock;
    LocationRequest locationRequest;
    FusedLocationProviderClient fusedLocationProviderClient;
    private FusedLocationProviderClient fusedLocationClient;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Date currentime= Calendar.getInstance().getTime();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        if (ActivityCompat.checkSelfPermission(MainActivity.this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{android.Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        }
        if (ActivityCompat.checkSelfPermission(MainActivity.this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        }
        //se inicializan las variables
        ip1 = findViewById(R.id.IP1);
        ip2 = findViewById(R.id.IP2);
        send = findViewById(R.id.send);
        tv_lat=findViewById(R.id.tv_lat);
        tv_lon=findViewById(R.id.tv_lon);
        tv_altitude=findViewById(R.id.tv_altitude);
        tv_accuracy=findViewById(R.id.tv_accuracy);
        tv_speed=findViewById(R.id.tv_speed);
        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        tv_lat.setText(String.valueOf(location.getLatitude()));
                        tv_altitude.setText(String.valueOf(location.getAltitude()));
                        tv_lon.setText(String.valueOf(location.getLongitude()));
                        tv_accuracy.setText(String.valueOf(location.getAccuracy()));
                        tv_speed.setText(String.valueOf(currentime));
                    }
                });
        try {
            dsock = new DatagramSocket();
        } catch (SocketException e) {
            throw new RuntimeException(e);
        }
        sock = new Socket();
        //Se le da funcionalidad la boton de enviar con un evento
        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View View) {
                //UDP sender

                SendData sender = new SendData();
                SendData sender2 = new SendData();
                sender.execute("Latitud: "+tv_lat.getText().toString()+" Longitud: "+tv_lon.getText().toString()+" Time: "+tv_speed.getText().toString(),ip1.getText().toString(),portudp);
                sender2.execute("Latitud: "+tv_lat.getText().toString()+" Longitud: "+tv_lon.getText().toString()+" Time: "+tv_speed.getText().toString(),ip2.getText().toString(),portudp);
                //TCP sender
                Sendtcp sendertcp = new Sendtcp();
                Sendtcp sendertcp2 = new Sendtcp();
                sendertcp.execute("Latitud: "+tv_lat.getText().toString()+" Longitud: "+tv_lon.getText().toString()+" Time: "+tv_speed.getText().toString(),ip1.getText().toString(),porttcp);
                sendertcp2.execute("Latitud: "+tv_lat.getText().toString()+" Longitud: "+tv_lon.getText().toString()+" Time: "+tv_speed.getText().toString(),ip2.getText().toString(),porttcp);
            }
        });
    }
    private class SendData extends AsyncTask<String,String,String>{
        @Override
        protected String doInBackground(String... strings) {
            try{
                InetAddress address = InetAddress.getByName(strings[1]);
                byte [] data = strings[0].getBytes();
                int port = Integer.parseInt(strings[2]);
                DatagramPacket packet = new DatagramPacket(data,data.length,address,port);
                dsock.send(packet);
            }catch (UnknownHostException e){
                e.printStackTrace();
                // Handle the exception here. For example, you can show an error message to the user.
            } catch (IOException e){
                e.printStackTrace();
            }
            return null;
        }
    }
    //Tcp sender class
    private class Sendtcp extends AsyncTask<String,String,String>{
        //Variable declaration
        Socket s;
        PrintWriter pw;
        @Override
        //method declaration doInBackground
        protected String doInBackground(String... voids){
            String message = voids[0];
            String ip = voids[1];
            int port = Integer.parseInt(voids[2]);
            try {
                s = new Socket(ip,port);
                pw = new PrintWriter(s.getOutputStream());
                pw.write(message);
                pw.flush();
                s.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}